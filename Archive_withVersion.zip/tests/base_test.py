# Copyright 2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/apache2.0
#
# or in the "license" file accompanying this file. This file is distributed
# on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
# express or implied. See the License for the specific language governing
# permissions and limitations under the License.

import unittest
from appium import webdriver

class BaseTest(unittest.TestCase):
	"""Basis for all tests."""
	def setUp(self):
		"""Sets up desired capabilities and the Appium driver."""
		url = 'http://127.0.0.1:4723/wd/hub'
		desired_caps = {}

		"""
		The following desired capabilities must be set when running locally.
		Make sure they are NOT set when uploading to Device Farm.
		"""
		desired_caps['platformName'] = 'iOS'
		# desired_caps['deviceName'] = 'iPhone 8'
		desired_caps['platformVersion'] = '12.0'
		desired_caps['automationName'] = 'XCUITest'
		# desired_caps['app'] = '/Users/lsida/Documents/developer/device_farm/Getting-Started-With-TDD-Swift-master/FizzBuzz-debug.app'

		# desired_caps['usePrebuiltWDA'] = True
		# desired_caps['derivedDataPath'] = '/Users/lsida/Library/Developer/Xcode/DerivedData/WebDriverAgent-advrryuwoeixtkapioakmpjarbot'

		self.driver = webdriver.Remote(url, desired_caps)

	def tearDown(self):
		"""Shuts down the driver."""
		self.driver.quit()

	def test_3(self):
		el1 = self.driver.find_element_by_accessibility_id('numberButton')
		el2 = self.driver.find_element_by_accessibility_id('fizzButton')
		el3 = self.driver.find_element_by_accessibility_id('buzzButton')
		el4 = self.driver.find_element_by_accessibility_id('fizzBuzzButton')

		el1.click();
		el1.click();
		el2.click();

		self.assertEqual(el1.text, '3')

	def test_5(self):
		el1 = self.driver.find_element_by_accessibility_id('numberButton')
		el2 = self.driver.find_element_by_accessibility_id('fizzButton')
		el3 = self.driver.find_element_by_accessibility_id('buzzButton')
		el4 = self.driver.find_element_by_accessibility_id('fizzBuzzButton')

		el1.click();
		el1.click();
		el2.click();
		el1.click();
		el3.click();

		self.assertEqual(el1.text, '5') 
